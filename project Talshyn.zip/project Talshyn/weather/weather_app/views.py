import requests
from django.shortcuts import render
from .forms import CityForm
from datetime import datetime

def weather_view(request):
    weather_today = None
    forecast_5days = []
    error = None

    if request.method == 'POST':
        form = CityForm(request.POST)
        if form.is_valid():
            city = form.cleaned_data['city']
            api_key = 'f4f88d5c07a5aee626f48420d01817ba'  # Получить можно на https://openweathermap.org/api

            # Получаем погоду на сегодня (текущая погода)
            url_today = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric&lang=ru"

            # Получаем прогноз на 5 дней (каждые 3 часа)
            url_forecast = f"http://api.openweathermap.org/data/2.5/forecast?q={city}&appid={api_key}&units=metric&lang=ru"

            response_today = requests.get(url_today)
            response_forecast = requests.get(url_forecast)

            if response_today.status_code == 200 and response_forecast.status_code == 200:
                data_today = response_today.json()
                data_forecast = response_forecast.json()

                # Погода сегодня
                weather_today = {
                    'city': data_today['name'],
                    'temperature': round(data_today['main']['temp']),
                    'description': data_today['weather'][0]['description'].capitalize(),
                    'icon': data_today['weather'][0]['icon'],
                    'humidity': data_today['main']['humidity'],
                    'wind': data_today['wind']['speed']
                }

                # Обработка прогноза на 5 дней — берем прогнозы по времени 12:00 (полдень)
                forecast_dict = {}
                for item in data_forecast['list']:
                    dt_txt = item['dt_txt']  # пример: "2025-10-22 12:00:00"
                    date_str = dt_txt.split(' ')[0]
                    time_str = dt_txt.split(' ')[1]

                    if time_str == "12:00:00" and len(forecast_dict) < 5:
                        forecast_dict[date_str] = {
                            'date': datetime.strptime(date_str, "%Y-%m-%d").strftime("%d %b, %A"),
                            'temperature': round(item['main']['temp']),
                            'description': item['weather'][0]['description'].capitalize(),
                            'icon': item['weather'][0]['icon'],
                            'humidity': item['main']['humidity'],
                            'wind': item['wind']['speed']
                        }

                forecast_5days = list(forecast_dict.values())

            else:
                error = 'Город не найден или ошибка при запросе данных'

    else:
        form = CityForm()

    return render(request, 'weather_app/weather.html', {
        'form': form,
        'weather_today': weather_today,
        'forecast_5days': forecast_5days,
        'error': error
    })
